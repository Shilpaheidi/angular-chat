import { Component } from '@angular/core';

@Component({
  selector: 'app-chat-space',
  templateUrl: './chat-space.component.html',
  styleUrls: ['./chat-space.component.scss']
})
export class ChatSpaceComponent {


  chats:any[]=['user1','user2','user3','user4'];
  chats2:any[]=['user1','user2','user3','user4'];
}
